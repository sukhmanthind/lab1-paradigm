//second question 2


let rec productTailRecursive list accumulator =
    match list with
    | [] -> accumulator
    | head :: tail -> productTailRecursive tail (accumulator * head)


let product = productTailRecursive [1; 2; 3; 4; 5] 1


printfn "Product of all elements: %d" product

// Tail Recursion 3 Product of All Odd Numbers from a Given Number to 1

let rec productOddNumbers n accumulator =
    if n < 1 then
        accumulator
    else if n % 2 = 1 then  
        productOddNumbers (n - 2) (accumulator * n)
    else
        productOddNumbers (n - 1) accumulator  


let productOdd = productOddNumbers 11 1


printfn "Product of all odd numbers from 11 to 1: %d" productOdd

//4 Using Map Function with a Collection




let Names: string list = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]

// Use List.map to trim spaces
let trimmedNames: string list = List.map (fun (name: string) -> name.Trim()) Names

printfn "Trimmed names: %A" trimmedNames

// 5 Using Filter and Reduce with a Collection:


let numbers = Seq.init 700 (fun i -> i + 1)  


let filteredNumbers = numbers |> Seq.filter (fun x -> x % 7 = 0 && x % 5 = 0)


let sumFiltered = filteredNumbers |> Seq.fold (+) 0


printfn "Sum of numbers divisible by both 7 and 5: %d" sumFiltered


 // 6 Using Filter and Reduce with a Collection of Strings


// List of names
let names5: string list = ["James"; "Robert"; "John"; "William"; "Michael"; "David"; "Richard"]
let filteredNames = 
    List.filter (fun (name: string) -> name.Contains("I") || name.Contains("i")) names5
let concatenatedNames = 
    match filteredNames with
    | [] -> "" // Handle empty case
    | _ -> List.reduce (fun acc name -> acc + name) filteredNames
printfn "Concatenated names: %s" concatenatedNames