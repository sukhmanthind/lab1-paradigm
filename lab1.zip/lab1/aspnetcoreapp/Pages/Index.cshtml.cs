using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace aspnetcoreapp.Pages;

public class IndexModel : PageModel
{
    private readonly ILogger<IndexModel> _logger;

    public IndexModel(ILogger<IndexModel> logger)
    {
        _logger = logger;
    }

    public void OnGet()
    {

    }

public void OnPost()
    {
 
        if (Request.Method.Equals("POST", System.StringComparison.OrdinalIgnoreCase)){
 
            if(Request.Form["ADD"]=="ADD"){
 
                ViewData["summation"]=double.Parse(Request.Form["num1"])+double.Parse(Request.Form["num2"]);
 
            }
            else if(Request.Form["Subtract"]=="Subtract"){
 
                ViewData["summation"]=double.Parse(Request.Form["num1"])-double.Parse(Request.Form["num2"]);
 
            }
            else if(Request.Form["Multiply"]=="Multiply"){
 
                ViewData["summation"]=double.Parse(Request.Form["num1"])*double.Parse(Request.Form["num2"]);
 
            }
            else if(Request.Form["Divide"]=="Divide"){
 
                ViewData["summation"]=double.Parse(Request.Form["num1"])/double.Parse(Request.Form["num2"]);
 
            }else if(Request.Form["Square"]=="Square"){
 
                ViewData["summation"]=double.Parse(Request.Form["num1"])*double.Parse(Request.Form["num1"]);

            }
            else if(Request.Form["Cube"]=="Cube"){
 
                ViewData["summation"]=double.Parse(Request.Form["num1"])*double.Parse(Request.Form["num1"])*double.Parse(Request.Form["num1"]);

            }
            else{
            }


        }
    }
}